# Digital Clock
I used HTML, CSS to make the design of the clock and to position it in the center and I used JavaScript to make the hands of the clock move in realtime. Realtime means it shows the exact time that we have right now.
